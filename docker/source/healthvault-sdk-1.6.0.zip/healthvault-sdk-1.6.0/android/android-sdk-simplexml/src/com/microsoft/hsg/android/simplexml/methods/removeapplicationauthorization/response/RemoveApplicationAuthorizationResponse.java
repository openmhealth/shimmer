package com.microsoft.hsg.android.simplexml.methods.removeapplicationauthorization.response;

import com.microsoft.hsg.android.simplexml.methods.response.Response;

public class RemoveApplicationAuthorizationResponse extends Response {
}
