package com.microsoft.hsg.android.simplexml.things.thing;

public interface HealthVaultThing {
	public String getThingType();
	
	public Thing2 getThing();
}
