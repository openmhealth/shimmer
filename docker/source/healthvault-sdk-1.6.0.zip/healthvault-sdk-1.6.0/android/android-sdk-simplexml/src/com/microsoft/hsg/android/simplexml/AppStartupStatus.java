package com.microsoft.hsg.android.simplexml;

public enum AppStartupStatus {
	Success,
	Pending,
	Failed,
	CredentialNotFound,
	Cancelled
}
