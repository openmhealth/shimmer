package com.microsoft.hsg.android.simplexml.client;

public class HealthVaultAsyncRequest {

}
