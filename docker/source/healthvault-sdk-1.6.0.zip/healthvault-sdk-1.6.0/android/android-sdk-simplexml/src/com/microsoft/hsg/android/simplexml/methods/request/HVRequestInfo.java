package com.microsoft.hsg.android.simplexml.methods.request;

public interface HVRequestInfo {
}
