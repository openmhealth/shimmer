package com.microsoft.hsg.android.simplexml.methods.removethings.response;

import org.simpleframework.xml.Root;

import com.microsoft.hsg.android.simplexml.methods.response.Response;

@Root(name = "response", strict=false)
public class RemoveThingsResponse extends Response {

}
