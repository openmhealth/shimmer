package com.microsoft.hsg.android.simplexml.things.types.base;

import java.util.Calendar;

public class Second extends ConstrainedInt {
	
	public Second() {
		this(Calendar.getInstance().get(Calendar.SECOND));
	}

	public Second(int value) {
		min = 0;
		max = 59;
		setValue(value);
	}
}
