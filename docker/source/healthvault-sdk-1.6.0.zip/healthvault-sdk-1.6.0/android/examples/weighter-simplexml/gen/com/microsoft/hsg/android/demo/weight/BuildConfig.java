/** Automatically generated file. DO NOT MODIFY */
package com.microsoft.hsg.android.demo.weight;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}