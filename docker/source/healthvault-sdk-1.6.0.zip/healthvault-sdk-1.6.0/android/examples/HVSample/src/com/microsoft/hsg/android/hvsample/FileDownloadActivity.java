package com.microsoft.hsg.android.hvsample;

import android.app.Activity;

public class FileDownloadActivity extends Activity {

}
