/** Automatically generated file. DO NOT MODIFY */
package com.microsoft.hsg.android.hvsample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}